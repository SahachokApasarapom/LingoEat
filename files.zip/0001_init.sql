-- ============================================================
-- ระบบฝึกทักษะภาษาอังกฤษเชิงสถานการณ์สำหรับร้านอาหารในชุมชน
-- Initial schema + RLS policies
-- ============================================================

-- ------------------------------------------------------------
-- 1. PROFILES (extends auth.users with role)
-- ------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  full_name text,
  role text not null default 'user' check (role in ('admin', 'user')),
  avatar_url text,
  created_at timestamptz not null default now()
);

-- Auto-create a profile row whenever a new user signs up via Supabase Auth
create function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, username, full_name)
  values (
    new.id,
    new.raw_user_meta_data ->> 'username',
    new.raw_user_meta_data ->> 'full_name'
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Helper: check if current user is admin (used inside RLS policies)
create function public.is_admin()
returns boolean
language sql
security definer set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- ------------------------------------------------------------
-- 2. LESSON CONTENT (managed by Admin — 1.3.1.2)
-- ------------------------------------------------------------
create table public.scenarios (
  id uuid primary key default gen_random_uuid(),
  name_th text not null,
  name_en text not null,
  description text,
  order_no int not null default 0,
  icon_url text,
  created_at timestamptz not null default now()
);

create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  scenario_id uuid not null references public.scenarios(id) on delete cascade,
  title text not null,
  description text,
  order_no int not null default 0,
  created_at timestamptz not null default now()
);

create table public.vocabulary (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  word_en text not null,
  meaning_th text not null,
  image_url text,
  audio_url text,
  created_at timestamptz not null default now()
);

create table public.media_clips (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  type text not null check (type in ('video', 'audio')),
  url text not null,
  caption text,
  created_at timestamptz not null default now()
);

create table public.exercises (
  id uuid primary key default gen_random_uuid(),
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  type text not null check (type in ('fill_blank_image', 'multiple_choice')),
  question text not null,
  image_url text,
  choices jsonb, -- e.g. ["Good morning", "Good night", "Goodbye"]
  correct_answer text not null,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- 3. USER PROGRESS (1.3.2.5 / 1.3.2.6)
-- ------------------------------------------------------------
create table public.user_answers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exercise_id uuid not null references public.exercises(id) on delete cascade,
  selected_answer text,
  is_correct boolean not null,
  answered_at timestamptz not null default now()
);

create table public.user_lesson_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  score int not null default 0,
  total_questions int not null default 0,
  completed_at timestamptz,
  unique (user_id, lesson_id)
);

-- ------------------------------------------------------------
-- 4. ROW LEVEL SECURITY
-- ------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.scenarios enable row level security;
alter table public.lessons enable row level security;
alter table public.vocabulary enable row level security;
alter table public.media_clips enable row level security;
alter table public.exercises enable row level security;
alter table public.user_answers enable row level security;
alter table public.user_lesson_progress enable row level security;

-- profiles: everyone (logged in) can read all profiles (needed for admin user-count report),
-- but can only edit their own row.
create policy "profiles_select_authenticated" on public.profiles
  for select to authenticated using (true);

create policy "profiles_update_own" on public.profiles
  for update to authenticated using (id = auth.uid());

-- lesson content: readable by any logged-in user, writable only by admin
create policy "scenarios_select" on public.scenarios
  for select to authenticated using (true);
create policy "scenarios_admin_write" on public.scenarios
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "lessons_select" on public.lessons
  for select to authenticated using (true);
create policy "lessons_admin_write" on public.lessons
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "vocabulary_select" on public.vocabulary
  for select to authenticated using (true);
create policy "vocabulary_admin_write" on public.vocabulary
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "media_clips_select" on public.media_clips
  for select to authenticated using (true);
create policy "media_clips_admin_write" on public.media_clips
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "exercises_select" on public.exercises
  for select to authenticated using (true);
create policy "exercises_admin_write" on public.exercises
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- user_answers: users can insert/read only their own; admin can read all
create policy "user_answers_insert_own" on public.user_answers
  for insert to authenticated with check (user_id = auth.uid());
create policy "user_answers_select_own_or_admin" on public.user_answers
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- user_lesson_progress: same pattern, plus users can update their own row
create policy "progress_insert_own" on public.user_lesson_progress
  for insert to authenticated with check (user_id = auth.uid());
create policy "progress_update_own" on public.user_lesson_progress
  for update to authenticated using (user_id = auth.uid());
create policy "progress_select_own_or_admin" on public.user_lesson_progress
  for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- ------------------------------------------------------------
-- 5. REPORT VIEWS (1.3.1.4)
-- ------------------------------------------------------------
create view public.report_user_count
with (security_invoker = true) as
  select count(*) as total_users
  from public.profiles
  where role = 'user';

create view public.report_score_summary
with (security_invoker = true) as
  select
    p.id as user_id,
    p.username,
    p.full_name,
    l.id as lesson_id,
    l.title as lesson_title,
    ulp.score,
    ulp.total_questions,
    ulp.completed_at
  from public.user_lesson_progress ulp
  join public.profiles p on p.id = ulp.user_id
  join public.lessons l on l.id = ulp.lesson_id;
