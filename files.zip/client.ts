import { createClient } from "@supabase/supabase-js";

// Safe to use in browser code — the anon key is public by design.
// Row Level Security (see supabase/migrations/0001_init.sql) is what
// actually protects the data, not this key.
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    "Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY. Check your .env file.",
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
