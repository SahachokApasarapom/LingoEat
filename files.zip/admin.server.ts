import { createClient } from "@supabase/supabase-js";

// SERVER-ONLY. The .server.ts suffix keeps this out of the client bundle
// (see eslint.config.js "server-only" restriction + TanStack Start convention).
// Never import this file from a component — it uses the service role key,
// which bypasses Row Level Security entirely.
//
// Use it only inside TanStack Start server functions / API routes, e.g. for
// bulk admin operations that don't go through a logged-in user's session.
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceRoleKey) {
  throw new Error(
    "Missing VITE_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY on the server. Check your .env file.",
  );
}

export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey, {
  auth: { persistSession: false },
});
