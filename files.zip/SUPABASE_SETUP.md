# ตั้งค่า Supabase Backend — คู่มือสำหรับโปรเจกต์นี้

## 1. สร้าง Supabase project
1. ไปที่ [supabase.com](https://supabase.com) → สร้างบัญชี/ล็อกอิน
2. New Project → ตั้งชื่อ, เลือก region ใกล้ที่สุด (Southeast Asia - Singapore), ตั้งรหัสผ่าน database
3. รอสร้างเสร็จ (~2 นาที)

## 2. Copy API keys
ไปที่ Project Settings → API แล้ว copy:
- **Project URL** → ใส่ใน `VITE_SUPABASE_URL`
- **anon public key** → ใส่ใน `VITE_SUPABASE_ANON_KEY`
- **service_role key** (คลิก Reveal) → ใส่ใน `SUPABASE_SERVICE_ROLE_KEY` — **ห้ามใส่ prefix `VITE_` เด็ดขาด** ไม่งั้นจะรั่วไปที่ browser

สร้างไฟล์ `.env` ที่ root โปรเจกต์โดย copy จาก `.env.example` แล้วใส่ค่าจริง (ไฟล์ `.env` ถูก ignore อยู่แล้วใน `.gitignore`)

## 3. รัน migration (สร้างตาราง + RLS)
ไปที่ Supabase Dashboard → SQL Editor → New query → วางเนื้อหาทั้งหมดจาก
`supabase/migrations/0001_init.sql` → กด Run

ตรวจสอบใน Table Editor ว่ามีตารางครบ: `profiles`, `scenarios`, `lessons`,
`vocabulary`, `media_clips`, `exercises`, `user_answers`, `user_lesson_progress`

## 4. ติดตั้ง Supabase client library
```bash
bun add @supabase/supabase-js
```

## 5. ตั้งตัวเองเป็น admin คนแรก
สมัครสมาชิกผ่านหน้าเว็บ 1 ครั้งก่อน (จะสร้างแถวใน `profiles` อัตโนมัติด้วย role='user')
จากนั้นไปที่ SQL Editor แล้วรัน:
```sql
update public.profiles set role = 'admin' where username = 'your-username';
```

## 6. วิธีเรียกใช้ในโค้ด
- **ฝั่ง client/component** → `import { supabase } from "@/lib/supabase/client"`
  ใช้ได้ทันที ปลอดภัยเพราะมี RLS policy คุมสิทธิ์อยู่แล้ว
- **ฝั่ง server function เท่านั้น** (เช่น bulk import ข้อมูลบทเรียนจาก admin,
  หรือ operation ที่ต้อง bypass RLS) → `import { supabaseAdmin } from "@/lib/supabase/admin.server"`
  ห้าม import ไฟล์นี้จาก component เด็ดขาด

## 7. (แนะนำ) Generate TypeScript types จาก schema จริง
```bash
bunx supabase gen types typescript --project-id your-project-ref > src/lib/supabase/types.ts
```
จะได้ type ของทุกตาราง ใช้กับ `createClient<Database>(...)` เพื่อ autocomplete/type-check
ตอน query ได้เต็มรูปแบบ

## ลำดับตารางโดยสรุป
| ตาราง | ใครแก้ได้ | ใครอ่านได้ |
|---|---|---|
| scenarios / lessons / vocabulary / media_clips / exercises | admin เท่านั้น | ผู้ใช้ที่ login แล้วทุกคน |
| user_answers / user_lesson_progress | เจ้าของแถวเท่านั้น (insert/update) | เจ้าของแถว หรือ admin |
| profiles | เจ้าของแถวเท่านั้น (update) | ทุกคนที่ login (select) |
